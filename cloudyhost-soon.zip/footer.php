      <footer class="footer">
        <p class="footer__copyright copyright">
          &copy; <?php echo date('Y'); ?> <?php _e('Copyright', 'wp-blank') ?> <?php bloginfo('name'); ?>
        </p>
      </footer>
    </div>
    <?php wp_footer(); ?>
  </body>
</html>
